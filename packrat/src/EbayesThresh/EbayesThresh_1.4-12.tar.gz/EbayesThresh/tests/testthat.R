library(testthat)
library(EbayesThresh)
test_check("EbayesThresh")
