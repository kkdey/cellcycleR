`Blocks` <-
function (x) 
{

y<-make.signal2("blocks",x=x)

y<-y+2

y<-y/7.2
y
}

