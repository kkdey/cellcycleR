`P3a` <-
function(t) 1.4*P3(t)

