`norm` <-
function(x,y){
e<-sqrt(sum((x-y)^2))

e
}

