"invansc" <-
function(y,n){

y<-y/sqrt(4*(n+.5))
x<-(sin(y)^2)*(n+3/4)-3/8
x
}

