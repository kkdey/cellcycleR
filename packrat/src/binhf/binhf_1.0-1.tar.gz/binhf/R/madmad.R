madmad <-
function (x) 
mad(x)^2
